import AuthLayout from "../components/Layouts/AuthLayout";
import FormLogin from "../components/Fragments/FormLogin";
import { Link } from "react-router-dom";

const LoginPage = (props) => {
  return (
    <AuthLayout title="Login" description="Welcome,Please enter your details">
      <FormLogin />
      <p className="text-sm mt-5 text-center">
        Don't have an account?{" "}
        <Link to="/registrasi" className="font-bold text-blue-600">
          Sign Up
        </Link>
      </p>
    </AuthLayout>
  );
};

export default LoginPage;
