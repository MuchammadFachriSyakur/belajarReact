import CardProduct from "../components/Fragments/CardProducts";

const Products = () => {
  return (
    <div className="w-full flex flex-wrap justify-center items-center p-5 gap-2">
      <CardProduct>
        <CardProduct.Header />
        <CardProduct.Body
          title="Apple Watch Series 9 Sport Loop Band - Garansi Resmi iBox, Desain
          minimalis, tali sporty yang nyaman digunakan, dan kompatibel dengan
          berbagai model Apple Watch sebelumnya ..."
          price="Rp1.000.000"
        />
      </CardProduct>
      <CardProduct>
        <CardProduct.Header />
        <CardProduct.Body
          title="Case iPhone 13 Pro Max Mini UAG Monarch Hybrid Shockproof Armor Casing - 13 Pro, Crimson"
          price="Rp450.000"
        />
      </CardProduct>
    </div>
  );
};

export default Products;
