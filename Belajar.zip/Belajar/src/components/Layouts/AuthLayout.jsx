const AuthLayout = (props) => {
  const { children, title, description } = props;
  return (
    <div className="min-h-screen m-auto flex flex-col justify-center items-center flex-wrap gap-4">
      <div className="w-full max-w-xs">
        <h1 className="text-blue-600 text-3xl font-bold my-2">{title}</h1>
        <p className="font-medium text-slate-500 mb-8">{description}</p>
        {children}
      </div>
    </div>
  );
};

export default AuthLayout;
