import Button from "../Elements/Button";
import InputForm from "../Elements/Input/Index";

const FormLogin = (props) => {
  return (
    <form action="" method="post">
      <InputForm
        label="email"
        placeholder="example@gmail.com"
        name="email"
        type="email"
      ></InputForm>
      <InputForm
        label="password"
        placeholder="***"
        name="password"
        type="password"
      ></InputForm>
      <Button classname="bg-blue-500 w-full">Login</Button>
    </form>
  );
};

export default FormLogin;
