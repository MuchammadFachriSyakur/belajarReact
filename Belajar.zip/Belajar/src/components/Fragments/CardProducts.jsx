import Button from "../../components/Elements/Button";
import Profile from "../../assets/P1.jpg";

const Card = (props) => {
  const { children } = props;
  return (
    <div className="w-full max-w-[250px] bg-white border border-gray-200 rounded-lg shadow">
      {children}
    </div>
  );
};

const Header = (props) => {
  return (
    <a href="#">
      <img
        src={Profile}
        alt="Product"
        className="rounded-t-lg w-full h-full max-h-[180px] bg-cover object-cover bg-no-repeat bg-center"
      />
    </a>
  );
};

const Body = (props) => {
  const { children, title, price } = props;
  return (
    <div className="px-3 pb-5 font-sans">
      <a href="#">
        <h5 className="text-[13px] font-normal text-black line-clamp-2 mt-2">
          {title}
        </h5>
      </a>
      <span className="mb-5 text-[15px] font-bold text-black">{price}</span>
      <div className="mt-2">
        <Button classname="bg-blue-600">Add To Cart</Button>
      </div>
    </div>
  );
};

Card.Header = Header;
Card.Body = Body;

export default Card;
