import Button from "../Elements/Button";
import InputForm from "../Elements/Input/Index";

const FormRegister = (props) => {
  return (
    <form action="" method="post">
      <InputForm
        label="Full name"
        placeholder="Insert your name here..."
        name="fullname"
        type="text"
      ></InputForm>
      <InputForm
        label="Email"
        placeholder="example@gmail.com"
        name="email"
        type="email"
      ></InputForm>
      <InputForm
        label="Password"
        placeholder="***"
        name="password"
        type="password"
      ></InputForm>
      <InputForm
        label="Confirm Password"
        placeholder="***"
        name="confirmPassword"
        type="password"
      ></InputForm>
      <Button classname="bg-blue-500 w-full">Register</Button>
    </form>
  );
};

export default FormRegister;
